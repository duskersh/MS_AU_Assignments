package com.tutorialpoint;

import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) 
	{
		/*
		 * ApplicationContext context = new
		 * ClassPathXmlApplicationContext("beansAnnotate.xml"); Student
		 * s=(Student)context.getBean("student"); System.out.println(s.getName());
		 * System.out.println(s.getAge());
		 */
		ApplicationContext context = new ClassPathXmlApplicationContext("beansAnnotate.xml");
		StudentDetails s=(StudentDetails)context.getBean("studentDetails"); 
		s.getStudentDetails();
		/*
		 * ClassA a=(ClassA)context.getBean("a"); a.printB();
		 */
	}

}
