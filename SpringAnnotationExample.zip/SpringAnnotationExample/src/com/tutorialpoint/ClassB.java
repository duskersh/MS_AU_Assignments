package com.tutorialpoint;

public class ClassB {
	public ClassB()
	{
		System.out.println("ClassB constructor called:Object created");
	}
    public void methodB()
    {
    	System.out.println("Inside MethodB!"); 
    }
}
