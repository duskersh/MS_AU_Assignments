package com.tutorialpoint;

import org.springframework.beans.factory.annotation.Autowired;

public class ClassA {
	//@Autowired
	private ClassB b;
	@Autowired
	public ClassA(ClassB b)
	{
		this.b=b;
	}
//	public ClassB getB() {
//		return b;
//	}
//	@Autowired
//	public void setB(ClassB b) {
//		this.b = b;
//	}
	public void printB()
	{
		b.methodB();
	}

}
