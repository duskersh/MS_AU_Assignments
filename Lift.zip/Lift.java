import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Lift 
{
	public void answer(int n,int cf,int p[])
	{
		ArrayList<Integer> lifta=new ArrayList<Integer>();
		ArrayList<Integer> liftb=new ArrayList<Integer>();
		ArrayList<Integer> lifta1=new ArrayList<Integer>();
		ArrayList<Integer> liftb1=new ArrayList<Integer>();

		for (int i=0;i<n;i++)		//Separating people going upstairs and downstairs
		{
			if (p[i]>cf)
			{
				lifta.add(p[i]);
			}
			else
			{
				liftb.add(p[i]);
			}
		}

		int len1=lifta.size();
		int len2=liftb.size();

		if(len1!=len2) 				//Dividing equal number of people in both lifts 
		{
			if(len1>len2)
			{
				Collections.sort(lifta);
				if((Math.abs(cf-lifta.get(0))>Math.abs(cf-lifta.get(len1-1))))
					Collections.reverse(lifta);
				for(int j=0;j<(((int)n/2)-len2);j++)
				{
					liftb.add(lifta.remove(0));
				}
				Collections.sort(lifta);
				Collections.sort(liftb);
			}
			else
			{
				Collections.sort(liftb);
				if((Math.abs(cf-liftb.get(0))>Math.abs(cf-liftb.get(len2-1))))
					Collections.reverse(liftb);						
				for(int j=0;j<((n/2)-len1);j++)
				{
					lifta.add(liftb.remove(0));
				}
				Collections.sort(lifta);
				Collections.sort(liftb);
			}
		}
		else
		{
			Collections.sort(lifta);
			Collections.sort(liftb);			
		}
		len1=lifta.size();
		len2=liftb.size();
		if((Math.abs(cf-lifta.get(0))>Math.abs(cf-lifta.get(len1-1))))
			Collections.reverse(lifta);
		if((Math.abs(cf-liftb.get(0))>Math.abs(cf-liftb.get(len2-1))))
			Collections.reverse(liftb);		
		/*System.out.println("Lift A Order of floors:" + lifta);
		System.out.println("Lift B Order of floors:" + liftb);*/
		int[] flag=new int[n];
		for(int j=0;j<n;j++)
			flag[j]=0;
		
		for(int j=0;j<lifta.size();j++)
		{
			for(int k=0;k<n;k++)
			{
				if(p[k]==lifta.get(j) && flag[k]==0)
				{
					lifta1.add(k+1);
					flag[k]=1;
					break;
				}
			}
		}
	
		for(int j=0;j<liftb.size();j++)
		{
			for(int k=0;k<n;k++)
			{
				if(p[k]==liftb.get(j) && flag[k]==0)
				{
					liftb1.add(k+1);
					flag[k]=1;
					break;
				}
			}
		}
		System.out.println("Exit order of people in Lift A:" + lifta1);
		System.out.println("Exit order of people in Lift B:" + liftb1);
		
	}
	public static void main(String[] args)
	{
		Optimize o=new Optimize();
		System.out.println("Enter the total number of people");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("Enter the current floor");
		int cf=sc.nextInt();
		int p[]=new int[n];
		System.out.println("Enter the choice of floor for each");
		for (int i=0;i<n;i++)
		{
			p[i]=sc.nextInt();
		}
		o.answer(n,cf,p);
		
	}

}
