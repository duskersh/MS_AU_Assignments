package com.learning.spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.basic.*;
import com.learning.dao.IEmployee;
import com.learning.model.Employee;


public class LearningSpring {

	public static void main(String[] args) 
	{
		ApplicationContext con=new ClassPathXmlApplicationContext("beans.xml");
		IEmployee employee=(IEmployee)con.getBean("employeeDoa");
		Employee employee_1=new Employee();
		
		
		employee_1.setId(31);
		employee_1.setName("Farook");
		employee_1.setAge(21);
		
		employee.saveEmployee(employee_1);
		//List<Employee> res=employee.viewEmployees();
		System.out.println(employee.viewEmployees());
		
		
//		ClassA a=(ClassA)con.getBean("a");
//		a.methodA();
//		System.out.println(a.getName());
//		InterfaceClassC c=(InterfaceClassC)con.getBean("c");
//		c.methodC();
	/*	gives error for logging using aspect,because the object is actually returned by the interface
	 	ClassC c=(ClassC)con.getBean("c");
		c.methodC();*/
		
	}

}

