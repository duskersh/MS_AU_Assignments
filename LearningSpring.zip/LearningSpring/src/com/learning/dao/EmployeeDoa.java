package com.learning.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.learning.model.Employee;

public class EmployeeDoa implements IEmployee{
	
	JdbcTemplate jTemplate;

	@Override
	public Boolean saveEmployee(Employee employee) {
		String sql = "insert into emp (id,name,age)" + "values(" + employee.getId() + "," + employee.getName() + "," + employee.getAge() + ")";
		System.out.println(sql);
		this.jTemplate.execute(sql);
		return null;
	}

	public JdbcTemplate getjTemplate() {
		return jTemplate;
	}

	public void setjTemplate(JdbcTemplate jTemplate) {
		this.jTemplate = jTemplate;
	}

	@Override
	public List<Employee> viewEmployees() {
		String sql="Select * from emp";
		return this.jTemplate.query(sql, new RowMapper<Employee>() {
						
			@Override
			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
				Employee e=new Employee();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setAge(rs.getInt(3));
				return e;
			}
			
		});
	}

}
