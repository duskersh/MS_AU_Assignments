package com.learning.dao;
import java.util.List;
import com.learning.model.Employee;

public interface IEmployee {

	/*
	 * Save Customer
	 * @param Employee
	 */
	Boolean saveEmployee(Employee e);
	
	List<Employee> viewEmployees();
	
}
