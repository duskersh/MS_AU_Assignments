package com.learning.basic;

public interface InterfaceClassC {
	public void methodC();

}
