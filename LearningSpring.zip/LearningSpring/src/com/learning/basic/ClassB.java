package com.learning.basic;

public class ClassB implements ClassBInterface {

	public String methodB()
	{
		return ("Inside Method B");
	}
}
