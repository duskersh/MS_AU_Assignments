package com.learning.basic;

public class ClassC implements InterfaceClassC {

	
	public void methodC()
	{
		System.out.println("Inside Method C");
	}
}
