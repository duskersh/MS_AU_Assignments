package com.learning.basic;

public interface ClassBInterface {

	public String methodB();
}