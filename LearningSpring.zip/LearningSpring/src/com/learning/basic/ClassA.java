package com.learning.basic;

//import org.springframework.beans.factory.annotation.Autowired;

public class ClassA {
	
	ClassBInterface b;
	String name;
	public ClassA(ClassBInterface b) 
	{
		this.b=b;
	}
	public void methodA()
	{
		System.out.println("Inside Method A");
		System.out.println(b.methodB());
	}
	public void init()
	{
		System.out.println("ClassA initialized");
	}
	public String getName()
	{
		System.out.println("Get method of A returns:");
		return name;
	}
	public void setName(String name)
	{
		System.out.println("Set method of A is called");
		this.name=name;
	}
}
