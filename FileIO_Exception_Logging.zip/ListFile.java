import java.io.*;
 
public class ListFile 
{
     
    public static void main(String[] args)
    {
    	    File file = new File("C:/Users/dharshna.mala/eclipse-workspace");
    		File[] files = file.listFiles();
    		System.out.println("Files ending with .txt");
    		for(File f: files)
    		{
    			String s=f.getName();
    			if(s.endsWith(".txt"))
    			{
    				if(f.delete())	
    					System.out.println(s+" is deleted successfully");
    			}
    		}
    }
}