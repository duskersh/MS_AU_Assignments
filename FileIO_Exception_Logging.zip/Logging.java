import java.io.*;
import java.util.*;
import java.lang.*;
import java.util.logging.*;

public class Logging 
{
	/*Logger logger = Logger.getLogger("MyLog"); 
	private static final Logger log1 = Logger.getLogger(Logging.class.getName());
	private static final Logger log2 = Logger.getLogger(Logging.class.getName());
	private static final Logger log3 = Logger.getLogger(Logging.class.getName());
	try
	{
	FileHandler fh = new FileHandler("C:/Users/dharshna.mala/Downloads/Collections and Generics");  
	logger.addHandler(fh);
	SimpleFormatter formatter = new SimpleFormatter();  
	fh.setFormatter(formatter);  
	}
	catch(Exception e)
	{
		System.out.println(e);
	}

	    */
	
	// private static Logger logger = Logger.getLogger(Logging.class);
	public static void main(String[] args) throws SecurityException, IOException 
	{
		Logger log1 = Logger.getLogger(Logging.class.getName());
		Logger log2 = Logger.getLogger(Logging.class.getName());
		Logger log3 = Logger.getLogger(Logging.class.getName());
		FileHandler fh1 = new FileHandler("C:/Users/dharshna.mala/Downloads/Collections and Generics/ArithmeticLog.txt");  
		log1.addHandler(fh1);
		SimpleFormatter format1 = new SimpleFormatter();  
		fh1.setFormatter(format1);  
		FileHandler fh2 = new FileHandler("C:/Users/dharshna.mala/Downloads/Collections and Generics/ArrayLog.txt");  
		log1.addHandler(fh2);
		SimpleFormatter format2 = new SimpleFormatter();  
		fh1.setFormatter(format2);  
		FileHandler fh3 = new FileHandler("C:/Users/dharshna.mala/Downloads/Collections and Generics/ExceptionLog.txt");  
		log1.addHandler(fh3);
		SimpleFormatter format3 = new SimpleFormatter();  
		fh1.setFormatter(format3);  

		try
		{
			int a = 0;
			int b = 100;
			int c = b/a;
			System.out.println("Result: " + c);
		}
		catch(ArithmeticException e)
		{
			//System.setErr(new PrintStream(new FileOutputStream(System.getProperty("user.home")+"/error.log")))
			//log.error("An exception! Oops!", e);
			// mLogger.error("Your log message", e);
			 //logger.error("Unexpected error", e);
			log1.log(Level.SEVERE, e.getMessage(),e );
			System.out.println(e);
		}
		try
		{
			int myArray[] = {0, 1, 2, 3, 4, 5};
			System.out.println(myArray[10]);
		}
		catch(ArrayIndexOutOfBoundsException e1)  
        {  
			log2.log(Level.SEVERE,  e1.getMessage(),e1 );
			System.out.println(e1);  
        }    
		try
		{
			FileReader fis=new FileReader("C:/Users/dharshna.mala/textf.txt");
			System.out.println(fis.read());
		}
		catch( IOException e3)
		{
			log3.log(Level.SEVERE, e3.getMessage(),e3 );
			System.out.println(e3);
		}
	}

}
