import java.io.*;

public class CopyFile {

	public static void main(String[] args)  
	{
		    try
			{
				FileInputStream fis = new FileInputStream("C:/Users/dharshna.mala/eclipse-workspace/textfile.txt"); 
		        FileOutputStream fos = new FileOutputStream("C:/Users/dharshna.mala/eclipse-workspace/textfilecopy.txt"); 
		        int b=fis.read(); 
		        while  ( b!= -1) 
		        {   fos.write(b);
		        	b=fis.read();
		        }
		        fis.close(); 
		        fos.close(); 
		    } 
		    catch( IOException e)
		    {
		    	System.out.print(e);
		    }
	
		}
}


