import java.io.*;
public class CopyFileFromDir 
{
	public void copyfile(String sourceLocation,String file1,String destination) throws IOException 
	{
					
					int val=0;
					File source1=new File(sourceLocation);
		            String[] children = source1.list();
		            for (int i=0; i<children.length; i++) 
		            {
		            	//System.out.println(children[i]);
		            	if(children[i].equals(file1)==true)
		            	{
		            		val=1;
		            		try
		        			{
		            			sourceLocation=sourceLocation+"/"+file1;
		        				FileInputStream fis = new FileInputStream(sourceLocation); 
		        		        FileOutputStream fos = new FileOutputStream(destination); 
		        		        int b=fis.read(); 
		        		        while  ( b!= -1) 
		        		        {   fos.write(b);
		        		        	b=fis.read();
		        		        }
		        		        fis.close(); 
		        		        fos.close(); 
		        		    } 
		        		    catch( IOException e)
		        		    {
		        		    	System.out.print(e);
		        		    }
		            	}
		            	if(val==1)
		            		break;
		            }
		            if(val==0)
		            	System.out.print("File NOt Found");
		       
	}
	public static void main(String[] args)
	{
		try
		{
			String source="C:/Users/dharshna.mala/eclipse-workspace";
			String des="C:/Users/Public/textfile.txt";
			String filename="textfile.txt";
			CopyFileFromDir obj=new CopyFileFromDir();
			obj.copyfile(source,filename,des);
		}
		catch( IOException e)
		{
			System.out.print(e);
		}
	}
}
