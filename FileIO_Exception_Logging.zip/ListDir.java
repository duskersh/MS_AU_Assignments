import java.io.File;
 
public class ListDir 
{
	public  void doFile(File file)
	{
	      System.out.println(file.getName());
    } 
	 public void dirTree(File dir) 
	 {
	      File[] subdirs=dir.listFiles();
	      for(File subdir: subdirs) 
	      {
	         if (subdir.isDirectory()) 
	         {
	            dirTree(subdir);
	         } else 
	         {
	            doFile(subdir);
	         }
	      }
	   }
	 
   public static void main(String[] args) 
   {
	   File f=new File("C:/Users/dharshna.mala/eclipse-workspace");
	   ListDir l=new ListDir();
	   l.dirTree(f);
   }
}