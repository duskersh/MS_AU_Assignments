import java.text.SimpleDateFormat;
import java.util.*;

class Network
{
	int Isincall(ContactP p)
	{
		return p.isInCall;
	}
	int doUWantToAttend(ContactP p)
	{
		System.out.println(p.name+" is calling");
		System.out.println("Do you want to attend?YES or NO");
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		if(name.equals("YES"))
			return 1;
		else 
			return 0;
	}
	void makeCall(ContactP c1,ContactP c2)
	{
		//c1 is calling c2
		Network n=new Network();
		int v=n.Isincall(c2);
		if(v==1)
		{	System.out.println(c1.name+" tried calling "+c2.name);
			System.out.println(c2.name+" is busy!");
		}
		else
		{
			System.out.println("Network Enabled...dialling");
			int val=n.doUWantToAttend(c1);
			if(val==1)
			{
				c2.isInCall=1;
			    Calendar cal = Calendar.getInstance();
		        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		        String time=sdf.format(cal.getTime());
		        //System.out.println( time );
		        Random rand = new Random();
		        int rno = rand.nextInt(1000);
		        Integer timeval = new Integer(rno);
		        String res1="Outgoing to "+c2.name+" : "+time;
		        String res2="Incoming from "+c1.name+" : "+time;
		        c1.map.put(res1, timeval);
		        c2.map.put(res2, timeval);
		        c2.isInCall=0;
			}
			else
			{
				String res=c2.name+" could not answer!";
				Integer timeval = new Integer(0);
				c1.map.put(res, timeval);
				String res1="Rejected call from "+c1.name;
				Integer timeval1 = new Integer(0);
				c2.map.put(res1, timeval1);
			}
		}
		
	}
	void receiveCall(ContactP c1,ContactP c2)
	{
		//c1 receives call from c2
		Network n1=new Network();
		int v=n1.doUWantToAttend(c2);
		if(v==1)
		{
			Calendar cal = Calendar.getInstance();
	        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	        String time=sdf.format(cal.getTime());
	        //System.out.println( time );
	        Random rand = new Random();
	        int rno = rand.nextInt(1000);
	        Integer timeval = new Integer(rno);
	        String res1="Outgoing to "+c1.name+" : "+time;
	        String res2="Incoming from "+c2.name+" : "+time;
	        c1.map.put(res2, timeval);
	        c2.map.put(res1, timeval);
		}
		else
		{
			String res=c1.name+" could not answer!";
			Integer timeval = new Integer(0);
			c2.map.put(res, timeval);
			String res1="Rejected call from "+c2.name;
			Integer timeval1 = new Integer(0);
			c1.map.put(res1, timeval1);
			
		}
	}
	void ViewHistory(ContactP p)
	{
		System.out.println("Call history of "+p.name+":");
		for(String str:p.map.keySet())
		{
			System.out.println(str+" "+p.map.get(str)+" seconds");
		}
	}
}
class ContactP 
{
	String name;
	int num;
	HashMap<String, Integer> map = new HashMap<>(); 
	int isInCall;
	public ContactP(String name,int num)
	{
		this.name=name;
		this.num=num;
		this.isInCall=0;
	}
}
public class Phone1
{
	public static void main(String[] arg)
	{
		ContactP[] c=new ContactP[10];
		System.out.println("Enter contacts and numbers:");
		for(int i=0;i<5;i++)
		{
			Scanner sc = new Scanner(System.in);
			String name = sc.nextLine();
			int number = sc.nextInt(); 
			c[i]=new ContactP(name,number);
		}
		Network n1=new Network();
		n1.makeCall(c[0],c[1]);
		//n1.receiveCall(c[1],c[0]);
		n1.makeCall(c[2],c[4]);
		//n1.receiveCall(c[4],c[2]);
		n1.makeCall(c[3],c[2]);
		n1.receiveCall(c[1],c[3]);
		//n1.makeCall(c[4],c[0]);
		//n1.receiveCall(c[0],c[4]);
		n1.ViewHistory(c[0]);
		n1.ViewHistory(c[1]);
		n1.ViewHistory(c[2]);
		n1.ViewHistory(c[3]);
		n1.ViewHistory(c[4]);
	}
}
