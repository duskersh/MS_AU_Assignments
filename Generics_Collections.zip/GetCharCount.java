import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class GetCharCount {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
			HashMap<Character, Integer> map = new HashMap<Character, Integer>();
			String s="Hey how are you?";
			String s1=s.toUpperCase();
			System.out.println(s1);
			for(int i=0;i<s1.length();i++)
			{
				if(Character.isLetter(s1.charAt(i)))
				{
					System.out.println(s1.charAt(i));
					Character c = s1.charAt(i);
				    Integer val = map.get(c);
				    if (val != null) 
				    {
				    	Integer no=new Integer(val);
				    	no=no+1;
				        map.put(c, no);
				    }
				    else 
				    {
				       map.put(c, 1);
				    }
				}
			}
			for(Character c:map.keySet())
			{
				System.out.print(c+" ");
				for(int i=0;i<map.get(c);i++)
				{
					System.out.print("#");
				}
				System.out.println();
			}
			/*Set set = map.entrySet();
		    Iterator iterator = set.iterator();
		      while(iterator.hasNext()) 
		      {
		         Map.Entry mentry = (Map.Entry)iterator.next();
		         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
		         System.out.println(mentry.getValue());
		      }*/
			/*Iterator<Integer> itr = map.values().iterator();
			while (itr.hasNext()) 
			{
				System.out.println(itr.next());
			}*/

	}

}
