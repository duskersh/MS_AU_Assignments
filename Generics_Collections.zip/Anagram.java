import java.util.*;

public class Anagram {
public static void main(String [] args)
{
	String s="maaam";
	HashMap<Character, Integer> map = new HashMap<Character, Integer>();
	//String s = "aasjjikkk";
	for (int i = 0; i < s.length(); i++)
	{
	    char c = s.charAt(i);
	    Integer val = map.get(c);
	    if (val != null) 
	    {
	    	Integer no=new Integer(val);
	    	no=no+1;
	        map.put(c, no);
	    }
	    else 
	    {
	       map.put(c, 1);
	   }
	}
	int count=0;
	for (Integer value : map.values()) 
	{
		if(value%2!=0)
        	count++;
	}
	/*Iterator it = map.entrySet().iterator(); 
	while (it.hasNext()) 
	{ 
        Map.Entry mapElement = (Map.Entry)it.next(); 
        int marks = (int)mapElement.getValue(); 
        if(marks%2!=0)
        	count++;
	}*/
	if(count>1)
		System.out.println("Not palindrome");
	else if(count==0 | count==1)
	{
		System.out.println("Palindrome");
	}
}
}
