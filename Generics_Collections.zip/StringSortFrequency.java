import java.util.*;

public class StringSortFrequency 
{
	public static void main(String[] args) 
	{
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			String[] s= {"abc","xyz","pqr","xyz","pqr","pqr"};
			for(int i=0;i<s.length;i++)
			{
				    Integer val = map.get(s[i]);
				    if (val != null) 
				    {
				    	Integer no=new Integer(val);
				    	no=no+1;
				        map.put(s[i], no);
				    }
				    else 
				    {
				       map.put(s[i], 1);
				    }
			}
			/*for(String str: map.keySet())
			{
				System.out.println(str+" "+map.get(str));
			}*/
			int size=map.size();
			/*Set<Entry<String, Integer>> set = map.entrySet();
	        List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(set);
	        Collections.sort( list, new Comparator<Map.Entry<String, Integer>>()
	        {
	            public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
	            {
	                return (o2.getValue()).compareTo( o1.getValue() );
	            }
	        } );
	        for(Map.Entry<String, Integer> entry:list){
	            System.out.println(entry.getKey()+" ==== "+entry.getValue());
	        }*/
			List<Map.Entry<String, Integer>> capitalList = new LinkedList<>(map.entrySet());

	        Collections.sort(capitalList, (o1, o2) -> o1.getValue().compareTo(o2.getValue()));
	        String ss[]=new String[size];
	        int index=0;
	        for (Map.Entry<String, Integer> entry : capitalList)
	        {
	        	ss[index]=entry.getKey();
	        	index++;
	        }
	        int l=0;
	        int r=index-1;
	        while(l<r)
	        {
	        	String temp=ss[l];
	        	ss[l]=ss[r];
	        	ss[r]=temp;
	        	l++;
	        	r--;
	        }
	        for(int i=0;i<index;i++)
	        {
	        	System.out.println(ss[i]);
	        }
	       
	}
		
}
