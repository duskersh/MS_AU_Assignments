import java.util.*;
import java.lang.*;

interface Comparable<T> 
{
    public boolean compareTo(T o);
}

public class Generics<T> implements Comparable 
{

	private T t;	
	public T get()
	{
		return this.t;
	}
	
	public void set(T t1)
	{
		this.t=t1;
	}
	@Override
	public boolean equals(Object g2)
	{
		T obj=(T)g2;
		if(Objects.equals(obj,t))
			return true;
		return false;
	}
	public boolean compareTo(Object g2)
	{
		T obj=(T)g2;
		if(Objects.equals(obj,t))
			return true;
		return false;

	}
	
	public static void main(String args[])
	{
		String s1,s2;
		int i1,i2;
		Scanner sc= new Scanner(System.in);
		System.out.println("String 1: ");
		s1=sc.next();
		System.out.println("String 2: ");
		s2=sc.next();
		Generics<String> g1 = new Generics<>();
		g1.set(s1);
		Generics<String> g2 = new Generics<>();
		g2.set(s2);
		if(g1.equals(g2))
			System.out.println("Both are equal");
		else
			System.out.println("They are not equal");
		System.out.println("Integer 1: ");
		i1=sc.nextInt();
		System.out.println("Integer 2: ");
		i2=sc.nextInt();
		Generics<Integer> g3 = new Generics<>();
		g3.set(i1);
		Generics<Integer> g4 = new Generics<>();
		g4.set(i2);
		if(g3.compareTo(g4))
			System.out.println("The Integers are equal");
		else
			System.out.println("The Integers are not equal");
		
	}	
}
